-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2020 at 09:47 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `000798104`
--

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` varchar(255) NOT NULL,
  `answer` varchar(1) NOT NULL COMMENT 'A letter representation of the answer(a,b,c)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `a`, `b`, `c`, `answer`) VALUES
(5, 'How do you create a function in JavaScript?', 'function myFunction()', 'function:myFunction()', 'call myFunction()', 'a'),
(6, 'How do you write \'Hello World\' in PHP?', '\'Hello World\'', 'echo \'Hello World\'', 'Document.Write(\'Hello World\')', 'b'),
(7, 'Which Sign does jQuery use as a shortcut for jQuery?', 'the % sign', 'the ? sign', 'the $ sign', 'c');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userName`, `password`, `email`, `creationDate`) VALUES
(10, 'username1', '$2y$10$FC2gDgxna33zyF5DCLx.ZOaSJls8aLF4Tw7fHVQaOsN', 'test2@test.com', '2020-12-13 02:47:02'),
(11, 'username2', '$2y$10$maAWRK2ANV/gWjlJ.L9YeON5RuNwwQIThRbEXyqjhRB', 'test3@test.com', '2020-12-13 02:49:06'),
(12, 'username4', '$2y$10$75KW9DLQfmXYPStOUz/P6eYNk2/wuySyqGc8.glvMk0', 'test4@test.com', '2020-12-13 02:50:56'),
(13, 'username5', '$2y$10$z5K/LL1StxWb6DTWxvGecewP6pKePtOfYJjj17uy6qV', 'test5@test.com', '2020-12-13 02:56:22'),
(14, 'username6', '$2y$10$ZPveLFPN79NMG4gIpcoDNeuAmdcqsn0DON6Fn3A69Ic', 'test6@test.com', '2020-12-13 02:58:09'),
(16, 'loganRothson', '$2y$10$/WANSf/clc7i65L5X55NC.iECKIHOr4rbkaMm3wKF8P', 'lcrothson@gmail.com', '2020-12-13 03:58:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userName` (`userName`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
