<?php  
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: Add a user to the database.
 */
include "connect.php";

$question = filter_input(INPUT_POST, "question", FILTER_SANITIZE_STRING);
$a = filter_input(INPUT_POST, "a", FILTER_SANITIZE_STRING);
$b = filter_input(INPUT_POST, "b", FILTER_SANITIZE_STRING);
$c = filter_input(INPUT_POST, "c", FILTER_SANITIZE_STRING);
$answer = filter_input(INPUT_POST, "answer", FILTER_SANITIZE_STRING);

$paramsok = false;
if(
    $question !== null && $question !== " " &&
    $a !== null && $a !== " " &&
    $b !== null && $b !== " " &&
    $c !== null && $c !== " " &&
    $answer !== null && $answer !== " "
    
) {
    $paramsok = true;
    $command = "INSERT into questions (question,a,b,c,answer) VALUES (?,?,?,?,?)";
    $stmt = $dbh->prepare($command);
    $params = [ $question,$a,$b,$c,$answer ];
    $success = $stmt->execute($params);
}
    
if($paramsok){

    $command = "INSERT INTO `questions` (`question`, `a`, `b`, `c`, `answer`) VALUES (?,?,?,?,?);";
    $stmt = $dbh->prepare($command);
    $params = [$question, $a, $b, $c, $answer ];
    $success = $stmt->execute($params);

    if ($success) {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        header("Location: addQuestionSuccess.php");  //redirect to success page
    }
    else {
        header("Location: addQuestionError.php");  //redirect to add failed page
    }
}

?>