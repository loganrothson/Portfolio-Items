<?php  
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: Add a user to the database.
 */
include "connect.php";
include "verifyUser.php";


$email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
$username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_STRING);
$password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_STRING);
$confirmPass = filter_input(INPUT_POST, "confirmPass", FILTER_SANITIZE_STRING);

$paramsok = verifyEmail($email) && verifyUsername($username) && verifyPassword($password) && verifyPasswords($password,$confirmPass);
    
if($paramsok){
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $command = "INSERT INTO `users` (`username`, `password`, `email`) VALUES (?, ?, ?);";
    $stmt = $dbh->prepare($command);
    $params = [$username, $password_hash, $email];
    $success = $stmt->execute($params);

    if ($success) {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $command2 = "SELECT * FROM `users` WHERE `username`=?";
        $stmt2 = $dbh->prepare($command2);
        $params2 = [$username];
        $success2 = $stmt2->execute($params2);
    
        if($stmt2->rowCount() == 1) {
            $row = $stmt2->fetch();
            $id = $row["id"];
        }

        $_SESSION['id'] = $id;
        $_SESSION['username'] = $username;
        header("Location: addUserSuccess.php");  //redirect to success page
    }
    else {
        header("Location: addUserError.php");  //redirect to register failed page
    }
}
else {
    header("Location: addUserError.php");  //redirect to register failed page
}
?>