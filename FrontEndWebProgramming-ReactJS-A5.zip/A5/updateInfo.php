<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: To update the users infromation
 */
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User Information</title>
</head>
<body>
    
</body>
</html>