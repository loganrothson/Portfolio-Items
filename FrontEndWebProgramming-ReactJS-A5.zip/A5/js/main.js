/**
 *  Author: Logan Rothson - 000798104
 *  Date Created: December 11th 2020
 */
window.addEventListener("load",function(){
    //Functions
    function displayQuestionPage(){
        window.location.replace("./questions.php");
        return false;
    }
    function displayDeletePage(){
        window.location.replace("./deleteQuestion.php");
        return false;
    }
    function displayAddPage(){
        window.location.replace("./addQuestionForm.php");
        return false;
    }
    function displayUpdatePage(){
        window.location.replace("./updateInfo.php");
        return false;
    }
    function displayLoginPage(){
        window.location.replace("./login.php");
        return false;
    }
    function displayRegisterUserPage(){
        window.location.replace("./addUserForm.php");
        return false;
    }

    //Variables
    const displayQuestionsBttn = document.getElementById('viewBttn');
    const displayDeleteBttn = document.getElementById('deleteBttn');
    const displayAddBttn = document.getElementById('addBttn');
    const displayUpdateBttn = document.getElementById('updateBttn');
    const displayLoginBttn = document.getElementById('loginBttn');
    const displayRegisterBttn = document.getElementById('registerBttn');

    //Event Listeners
    if(displayQuestionsBttn != null) {
        displayQuestionsBttn.addEventListener('click',displayQuestionPage);
    }
    if (displayDeleteBttn != null) {
        displayDeleteBttn.addEventListener('click',displayDeletePage);
    }
    if (displayAddBttn != null) {
        displayAddBttn.addEventListener('click',displayAddPage);
    }
    if (displayUpdateBttn != null) {
        displayUpdateBttn.addEventListener('click',displayUpdatePage);
    }
    if (displayLoginBttn != null) {
        displayLoginBttn.addEventListener('click',displayLoginPage);
    }
    if (displayRegisterBttn != null) {
        displayRegisterBttn.addEventListener('click',displayRegisterUserPage);
    }
});