<?php  
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: verify user is logged in.
 */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

//if id not set redirect to login page
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
}

?>