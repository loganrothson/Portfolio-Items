<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: display a form for the user to add questions to the database
 */
session_start();

include "connect.php";
// include "addUser.php";

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add a Question</title>
    <script src="js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="Stylesheet" href="css/styleAddQuestion.css">
</head>
<body>
    <div id="addUserContent">
        <form method="POST" action="addUser.php">
            <h1><u>Please enter your question below!</u></h1><br><br><br>
            <input type="text" name="question" id="question" placeholder="Question" required><br><br>
            <input type="text" name="a" id="a" placeholder="a" maxlength="100" minlength="1"  required>
            <input type="text" name="b" id="b" placeholder="b" maxlength="100" minlength="1"  required>
            <input type="text" name="c" id="c" placeholder="c" maxlength="100" minlength="1"  required><br><br>
            <input type="text" name="answer" id="answer" placeholder="Answer" maxlength="1"  required><br>
            <p>Inorder to add a question you need to enter the question in the first box and 3 possible answers in the a,b & c box's. 
               Once all the answers are input place the correct answer's letter in the answer box. 
            </p>
            
            
            <input type="submit" value="Submit Form">
            <h3>Changed your mind? Go back to the main menu <a href="mainMenu.php">HERE</a></h3>
        </form>
        <footer>
            Author: Logan Rothson - 000798104
        </footer>
    </div>
</body>
</html>