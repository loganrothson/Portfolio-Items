<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: display a success page when a user is added to the database.
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "isLoggedIn.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success! User Added!</title>
    <script src="js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="Stylesheet" href="css/styleAddUserForm.css">
</head>
<body>
    <div id="addUserContent">
        <h1><u>Welcome <?php echo $_SESSION['username'] ?>!</u></h1>
        <h3><a href="mainMenu.php">Click to proceed</a></h3>
        <footer>
            Author: Logan Rothson - 000798104
        </footer>
    </div>
</body>
</html>