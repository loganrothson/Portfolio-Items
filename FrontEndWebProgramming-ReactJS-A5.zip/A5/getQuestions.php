<?php  
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: To get the questions from the database
 */
include "connect.php";
include "question.php";

$command = "SELECT question,answer1,answer2,answer3,answer4,answer FROM questions";
$stmt = $dbh->prepare($command);
$success = $stmt->execute();

// Fill an array with question objects based on the results.
$questions = [];
while ($row = $stmt->fetch()) {
    $question = [
        "question" => $row["question"],
        "answer1" => $row["answer1"],
        "answer2" => $row["answer2"],
        "answer3" => $row["answer3"],
        "answer4" => $row["answer4"],
        "answer" => $row["answer"]
    ];
    array_push($questions, $question);
}

// Write the json encoded array to the HTTP Response
echo json_encode($questions);


?>