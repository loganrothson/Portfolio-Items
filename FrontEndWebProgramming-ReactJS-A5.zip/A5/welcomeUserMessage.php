<?php  
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: print welcome message
 */

include "isLoggedIn.php";
echo "<h1><u>Welcome " . $_SESSION['username'] . "</u></h1>";

?>