<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: display an error page when the user can not login
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Error!</title>
    <script src="js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="Stylesheet" href="css/styleAddUserForm.css">
</head>
<body>
    <div id="addUserContent">
        <h1><u>Failed to login.</u> </h1>
        <a href="login.php">Click here to try again</a>
    </div>
        <footer>
            Author: Logan Rothson - 000798104
        </footer>
    </div>
</body>
</html>