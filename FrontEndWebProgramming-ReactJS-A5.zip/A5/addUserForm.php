<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: display a form for the user to be added to the system.
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "connect.php";
// include "addUser.php";

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User Form</title>
    <script src="js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="Stylesheet" href="css/styleAddUserForm.css">
</head>
<body>
    <div id="addUserContent">
        <form method="POST" action="addUser.php">
            <h1><u>Welcome new user!</u></h1>
            <input type="email" name="email" id="email" placeholder="Email Adrress" required>
            <input type="text" name="username" id="username" placeholder="Username" maxlength="30" minlength="6" required>
            <input type="password" name="password" id="password" placeholder="Password" maxlength="20" minlength="8" required>
            <input type="password" name="confirmPass" id="confirmPass" placeholder="Comfirm Password" maxlength="20" minlength="8"  required>
            <div id="passInfo">
                <h3>The password must meet the below conditions:</h3>
                <ul>
                    <li>At least one uppercase letter</li>
                    <li>At least one lowercase letter</li>
                    <li>At least one number letter</li>
                    <li>length between 8-20</li>
                </ul>
            </div>
            <input type="submit" value="Submit Form">
            <h3>Already have an account? Please sign in <a href="login.php">HERE</a></h3>
        </form>
        <footer>
            Author: Logan Rothson - 000798104
        </footer>
    </div>
</body>
</html>