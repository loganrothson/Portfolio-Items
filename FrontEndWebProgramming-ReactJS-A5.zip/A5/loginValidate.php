<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: to validate 
 *          the login information being sent from the login.php file
 */
include "connect.php";
include "verifyUser.php";

$username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS);
$password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_STRING);

$paramsok = true;
if ($username === null || empty($username)) {
    $paramsok = false;
}
if ($password === null || empty($password)) {
    $paramsok = false;
}

//Validate the login
if($paramsok){
    $command = "SELECT * FROM `users` WHERE `username`=?";
    $stmt = $dbh->prepare($command);
    $params = [$username];
    $success = $stmt->execute($params);

    if ($success) {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $command2 = "SELECT * FROM `users` WHERE `username`=?";
        $stmt2 = $dbh->prepare($command2);
        $params2 = [$username];
        $success2 = $stmt2->execute($params2);
    
        if($stmt2->rowCount() == 1) {
            $row = $stmt2->fetch();
            $id = $row["id"];
        }

        $_SESSION['id'] = $id;
        $_SESSION['username'] = $username;
        header("Location: addUserSuccess.php");  //redirect to success page
            
        
    }
    else {
        header("Location: loginError.php");  //redirect to login failed page
    }
}
?>