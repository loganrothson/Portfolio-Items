<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: To login to the webapp
 */
session_start();

include "connect.php";
include "loginValidate.php";

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <script src="js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/styleLogin.css">
</head>
<body>
    <div id="LoginContent">
        <div id="header">
            <h1><u>Please enter your username and password</u></h1>
        </div>
        <form id="loginForm" action="loginValidate.php" method="POST">
            <input type="text" name="username" placeholder="Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="submit" name="signinBttn" value="Sign In">

            <h4>Click <a href="addUserForm.php">HERE</a> to register an account</h4>
        </form>
        <footer>
            Author: Logan Rothson - 000798104
        </footer>
    </div>
</body>
</html>