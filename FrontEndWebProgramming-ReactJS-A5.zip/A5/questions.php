<?php
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: to display the questions
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Buddy Quiz!</title>
    <script src="js/questions.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="Stylesheet" href="css/styleQuestions.css">
</head>
<body>
    <h1>Study Buddy Quiz</h1>
    <div class="quiz-container">
        <div id="quiz"></div>
    </div>
    <button id="previous">Previous Question</button>
    <button id="next">Next Question</button>
    <button id="submit">Submit Quiz</button>
    <button id="menu">Back To Menu</button>
    <div id="results"></div>
</body>
</html>