<?php  
/**
 * Author: Logan Rothson - 000798104
 * Date Created: December 11th 2020
 * Purpose: to display a menu for the user
 */

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Menu</title>
    <script src="js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/styleMenu.css"> 
</head>
<body>
    <h1>Welcome! Please select what you would like to do from our menu!</h1>
        <button id="viewBttn">View Questions</button>
        <button id="deleteBttn">Delete Questions</button>
        <button id="addBttn">Add Questions</button>
        <button id="updateBttn">Update information</button>
    <footer>
        Author: Logan Rothson - 000798104
    </footer>
</body>
</html>