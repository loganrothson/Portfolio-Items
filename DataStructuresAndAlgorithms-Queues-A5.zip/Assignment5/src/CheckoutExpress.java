/**
 * @author Logan Rothson - 000798104
 * SOA: I Logan Rothson, 000798104 certify that this material is my original work.
 *      No other person’s work has been used without due acknowledgement.
 *      I have not made my work available to anyone else.
 *
 * Purpose: This class outlines an express checkout queue
 */
public class CheckoutExpress extends Checkout{

    //Item limit for the express checkout
    private int itemLimit;

    /**
     * When the checkout is created its setting the incremented checkout id from
     * the super class and it's setting the item limit of the checkout.
     * @param itemLimit item limit of checkout
     */
    public CheckoutExpress(int itemLimit){
        super();
        this.itemLimit = itemLimit;
    }

    /**
     * Overriding the isValidCustomer method from the super class to make sure
     * the item count is less than the item limit so they can be in the express checkout.
     * @param customer in the queue
     * @return if the customer is valid to be in the express checkout
     */
    @Override
    public boolean isValidCustomer(Customer customer){
        boolean temp = customer.getItemCount() <= itemLimit;
        return temp;
    }

    /**
     * @return a string of the checkout type with the estimated time.
     */
    @Override
    public String toString(){
        return String.format("Checkout(Express) # %d (Estimated Time = %d s) = %s",
        this.getId(), this.getCurrentQueueTime(), this.getCustomers().toString());
    }
}