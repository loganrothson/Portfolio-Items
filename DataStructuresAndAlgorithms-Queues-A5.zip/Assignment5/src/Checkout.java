/**
 * @author Logan Rothson - 000798104
 * SOA: I Logan Rothson, 000798104 certify that this material is my original work.
 *      No other person’s work has been used without due acknowledgement.
 *      I have not made my work available to anyone else.
 *
 * Purpose: This class outlines a checkout queue
 */
public class Checkout {

    //Checkout id
    private int id;
    //last checkout id starts at 1 so when more checkouts are created they are incremented starting at 1
    private static int lastID = 1;
    //The total processing time for the queue
    private int totalProcessedTime;
    //The current time remaining in the queue
    private int currentQueueTime;

    //Creating a linkedQueue of customers in the checkout
    private LinkedQueue<Customer> customers = new LinkedQueue<>();

    /**
     * When the checkout is created its setting the incremented checkout id
     */
    public Checkout(){ id = lastID++; }

    /**
     * @return checkout id
     */
    public int getId(){ return id; }

    /**
     * @return total processing time
     */
    public int getTotalProcessedTime(){ return totalProcessedTime;}

    /**
     * @return current Queue time of the checkout
     */
    public int getCurrentQueueTime(){ return currentQueueTime; }

    /**
     * @return customers in the queue
     */
    public LinkedQueue<Customer> getCustomers() { return customers; }

    /**
     * @param customer in the queue
     * @return true if valid customer
     */
    public boolean isValidCustomer(Customer customer){ return true; }

    /**
     * @param value of customer
     */
    public void enqueue(Customer value){
        if(value != null){
            this.customers.enqueue(value);
            this.currentQueueTime += value.getServeTime();
        }
    }

    /**
     * @return customer being dequeued.
     */
    public Customer dequeue(){
        Customer customer = this.customers.dequeue();
        if(customer != null){
            this.currentQueueTime -= customer.getServeTime();
            this.totalProcessedTime += customer.getServeTime();
        }
        return customer;
    }

    /**
     * @return if the queue is empty
     */
    public boolean isEmpty(){ return this.customers.isEmpty(); }

    /**
     * @return a view of the customer
     */
    public Customer peek(){ return this.customers.peek(); }

    /**
     * @return size of the queue
     */
    public int size(){ return this.customers.size(); }

    /**
     * @return a string of the checkout type with the estimated time.
     */
    @Override
    public String toString(){
        return String.format("Checkout(Normal) # %d (Estimated Time = %d s) = %s",
                this.getId(), this.getCurrentQueueTime(), customers.toString());
    }
}