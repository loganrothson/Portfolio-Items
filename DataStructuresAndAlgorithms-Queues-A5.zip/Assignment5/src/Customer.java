/**
 * @author Logan Rothson - 000798104
 * SOA: I Logan Rothson, 000798104 certify that this material is my original work.
 *      No other person’s work has been used without due acknowledgement.
 *      I have not made my work available to anyone else.
 *
 * Purpose: This class is the outline of a customer
 */
public class Customer {
    //count of items the customer has
    private int itemCount;

    /**
     * Customer constructor
     * @param itemCount amount of items customer has
     */
    public Customer(int itemCount){ this.itemCount = itemCount; }

    /**
     * calculation to get the customer's serve time based on itemCount the customer has
     * @return customer serve time
     */
    public int getServeTime(){ return 45 + (5 * itemCount); }

    /**
     * @return the amount of items the customer has
     */
    public int getItemCount(){ return itemCount; }

    /**
     * @return String representation of a Customer showing the amount of items and the serve time.
     */
    @Override
    public String toString(){ return String.format("[%d(%d s)]", this.itemCount, this.getServeTime() ); }
}