import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * @author Logan Rothson - 000798104
 * SOA: I Logan Rothson, 000798104 certify that this material is my original work.
 *      No other person’s work has been used without due acknowledgement.
 *      I have not made my work available to anyone else.
 *
 * Purpose: This class creates the checkout queues
 */
public class Assignment5 {
    public static void main(String[] args) {
        //Reading in the checkout file data
        String filename = "src/CustomerData.txt";
        int f_expressLanes = 0;
        int n_normalLanes = 0;
        int x_itemLimit = 0;
        LinkedQueue<Customer> customers = new LinkedQueue<>();
        try{
            Scanner fin = new Scanner(new File(filename));
            //Get f_expressLanes
            f_expressLanes = fin.nextInt();
            //Get n_normalLanes
            n_normalLanes = fin.nextInt();
            //Get x_itemLimit
            x_itemLimit = fin.nextInt();

            //Get customers
            while(fin.hasNextInt()){
                int nextInt = fin.nextInt();
                customers.enqueue(new Customer(nextInt));
            }
            //Close the file
            fin.close();
        }
        //Catch the exception for when the file is not found
        catch (FileNotFoundException ex){
            System.out.println("Exception = " + ex.getMessage());
            System.exit(-1);
        }
        //Creating the checkout lanes
        int totalLanes = f_expressLanes + n_normalLanes;
        Checkout [] checkouts = new Checkout[totalLanes];

        int count = 1;
        for(int i = 0; i < totalLanes; i++){
            if(i < f_expressLanes)
                checkouts[i] = new CheckoutExpress(x_itemLimit);
            else
                checkouts[i] = new Checkout();
        }

        //********** Part A **********
        System.out.println();
        System.out.println("PART A - Checkout lines and time estimated for each line");
        System.out.println();
        Customer currentCustomer = null;
        //For Each of the customers find the lowest queue time
        while( !customers.isEmpty() && (currentCustomer = customers.dequeue()) != null){
            int checkoutIndex = f_expressLanes;
            int lowestTime = checkouts[checkoutIndex].getCurrentQueueTime();
            boolean queueComplete = false;
            for(int i = 0; i < totalLanes && !queueComplete; i++){
                if(checkouts[i].isValidCustomer(currentCustomer)){
                    if(checkouts[i].isEmpty()){
                        checkouts[i].enqueue(currentCustomer);
                        queueComplete = true;
                    }
                    else if(checkouts[i].getCurrentQueueTime() < lowestTime){
                        checkoutIndex = i;
                        lowestTime = checkouts[i].getCurrentQueueTime();
                    }
                }
            }
            if(queueComplete)
                continue;
            checkouts[checkoutIndex].enqueue(currentCustomer);
        }
        for(int i = 0; i < totalLanes; i++){
            System.out.println(checkouts[i]);
        }
        System.out.println();

        //********** Part B **********
        final int step = 1;         //every second
        final int frequency = 60;   //every minute
        System.out.println("PART B - Number of customers in line after each minute (60s)");
        System.out.println();
        System.out.println(getRowText(checkouts, true, 0));
        int time = 1;
        for(time = 1; !allCheckoutsEmpty(checkouts); time += step) {
            //process the queues
            for(int i = 0; i < totalLanes; i++){
                Customer customer = checkouts[i].peek();
                //Checks if the customer can be removed
                if(customer != null && time >= checkouts[i].getTotalProcessedTime() + customer.getServeTime())
                    checkouts[i].dequeue();
            }
            //Check if it's time to print to screen
            if(time % frequency == 0){
                System.out.println(getRowText(checkouts, false, time));
            }
        }
        System.out.println(getRowText(checkouts, false, time));
    }

    /**
     * @param checkout array of checkouts
     * @param headersOnly column headers
     * @param interval of printing
     * @return the rows of customers in the lanes still
     */
    public static String getRowText(Checkout [] checkout, boolean headersOnly, int interval){
        String output = "";
        if(headersOnly){
            output = String.format("%10s","t(s)");
        }
        else{
            output = String.format("%10s",interval);
        }
        for(int i = 0; i < checkout.length; i++){
            if(headersOnly){
                output += String.format("%10s","Line " + (i + 1));
            }
            else{
                output += String.format("%10s", checkout[i].size());
            }
        }
        return output;
    }

    /**
     * @param checkout lane being checked if empty
     * @return if lane is empty or not
     */
    public static boolean allCheckoutsEmpty(Checkout [] checkout){
        for (int i = 0; i < checkout.length; i++){
            if(!checkout[i].isEmpty())
                return false;
        }
        return true;
    }
}
